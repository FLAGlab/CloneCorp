//
//  Constants.swift
//  Upupu
//
//  Created by Toshiki Takeuchi on 8/30/16.
//  Copyright © 2016 Xcoo, Inc. All rights reserved.
//  See LISENCE for Upupu's licensing information.
//

import Foundation

struct Constants {

    struct Dropbox {

        static let kDBAppKey = "YOUR_DROPBOX_APP_KEY"

    }

}

# Home Thermostat

Mobile App for esp based home thermostat system. Is is always connected with socket.io


UI Credit: https://github.com/mahmed8003/thermostat

![](screenshots/ss.png)

# Video[TR]

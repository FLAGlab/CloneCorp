import 'package:flutter/material.dart';
import 'package:thermostat/src/app.dart';
import 'package:thermostat/src/ui/thermostat_screen.dart';

void main() => runApp(App());




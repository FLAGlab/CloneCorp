class AppStrings {
  static const followingString = "Following";
  static const forYouString = "For You";

}

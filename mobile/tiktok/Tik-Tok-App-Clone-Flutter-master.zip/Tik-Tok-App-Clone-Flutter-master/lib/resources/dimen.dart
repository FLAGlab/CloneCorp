class Dimen {
  static const bottomNavigationTextSize = 8.5;
  static const createButtonBorder = 9.0;
  static const defaultTextSpacing = 5.0;
  static const textSpacing = 2.0;
  static const headerHeight = 50.0;
  static const five = 5;
}

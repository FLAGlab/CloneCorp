package com.bytedance.tiktok.utils.autolinktextview;

public interface AutoLinkOnClickListener {

    void onAutoLinkTextClick(AutoLinkMode autoLinkMode, String matchedText);
}

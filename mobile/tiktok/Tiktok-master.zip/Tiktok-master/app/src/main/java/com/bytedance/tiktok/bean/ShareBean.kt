package com.bytedance.tiktok.bean

/**
 * create by libo
 * create on 2020-06-04
 * description
 */
class ShareBean(var iconRes: Int, var text: String, var bgRes: Int)
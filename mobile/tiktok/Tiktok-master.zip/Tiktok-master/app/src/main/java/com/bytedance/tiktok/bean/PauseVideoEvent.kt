package com.bytedance.tiktok.bean

/**
 * create by libo
 * create on 2020-05-21
 * description
 */
class PauseVideoEvent(val isPlayOrPause: Boolean)
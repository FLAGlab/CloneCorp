package com.bytedance.tiktok.bean

import com.bytedance.tiktok.bean.VideoBean.UserBean

/**
 * create by libo
 * create on 2020-06-04
 * description 当前播放视频的作者Userbean切换
 */
class CurUserBean(var userBean: UserBean)
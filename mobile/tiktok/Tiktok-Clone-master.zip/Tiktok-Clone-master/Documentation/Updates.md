# Updates

### 10/05/2020 Add functions in Media Module

- Ask users for camera, microphone, photo library access
- Shooting Videos with audio
- Uploading videos to database with caption

### 09/26/2020 Initial Uploding project to github


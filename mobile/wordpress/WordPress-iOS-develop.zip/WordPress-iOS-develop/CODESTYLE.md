# Code Style Guidelines for WordPress-iOS

Our code style guidelines (for both Swift and Objective-C) is located [here](docs/coding-style-guide.md).


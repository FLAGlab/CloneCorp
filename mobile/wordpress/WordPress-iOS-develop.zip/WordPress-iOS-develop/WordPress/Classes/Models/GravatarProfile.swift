import Foundation

public struct GravatarProfile {

    var profileID = ""
    var hash = ""
    var requestHash = ""
    var profileUrl = ""
    var preferredUsername = ""
    var thumbnailUrl = ""
    var name = ""
    var displayName = ""

}

#import "PostType.h"

@implementation PostType

@dynamic label;
@dynamic name;
@dynamic apiQueryable;
@dynamic blog;

@end

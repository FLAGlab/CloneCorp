import Foundation
import CoreData


public class StreakStatsRecordValue: StatsRecordValue {

}

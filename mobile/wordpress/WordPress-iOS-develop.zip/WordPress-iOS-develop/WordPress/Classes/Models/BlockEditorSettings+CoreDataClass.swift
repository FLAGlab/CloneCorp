import Foundation
import CoreData

@objc(BlockEditorSettings)
public class BlockEditorSettings: NSManagedObject {

}

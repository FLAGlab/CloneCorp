import Foundation

@objc open class SiteInfo: NSObject {
    @objc var name = ""
    @objc var tagline = ""
    @objc var url = ""
    @objc var hasJetpack = false
    @objc var icon = ""
}

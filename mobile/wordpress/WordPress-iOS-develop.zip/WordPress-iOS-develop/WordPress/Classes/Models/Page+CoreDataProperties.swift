import Foundation
import CoreData

extension Page {

    @NSManaged var parentID: NSNumber?

}

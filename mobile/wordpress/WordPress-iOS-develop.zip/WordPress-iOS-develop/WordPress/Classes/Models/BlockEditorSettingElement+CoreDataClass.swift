import Foundation
import CoreData

@objc(BlockEditorSettingElement)
public class BlockEditorSettingElement: NSManagedObject {

}

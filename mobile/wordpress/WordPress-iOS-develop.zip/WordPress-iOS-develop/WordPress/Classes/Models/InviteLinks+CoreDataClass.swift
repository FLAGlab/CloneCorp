import Foundation
import CoreData

@objc(InviteLinks)
public class InviteLinks: NSManagedObject {

}

import Foundation
import CoreData


class DiffTitleValue: DiffAbstractValue {
    @NSManaged var revisionDiff: RevisionDiff?
}

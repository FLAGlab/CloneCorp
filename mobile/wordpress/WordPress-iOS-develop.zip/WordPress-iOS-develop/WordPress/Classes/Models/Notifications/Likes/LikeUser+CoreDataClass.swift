import CoreData

@objc(LikeUser)
public class LikeUser: NSManagedObject {

}

import CoreData

@objc(LikeUserPreferredBlog)
public class LikeUserPreferredBlog: NSManagedObject {

}

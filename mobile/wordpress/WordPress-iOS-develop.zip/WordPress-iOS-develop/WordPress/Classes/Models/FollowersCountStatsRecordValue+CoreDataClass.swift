import Foundation
import CoreData


public class FollowersCountStatsRecordValue: StatsRecordValue {

}

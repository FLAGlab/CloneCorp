import Foundation
import CoreData

@objc(PageTemplateCategory)
public class PageTemplateCategory: NSManagedObject {

}

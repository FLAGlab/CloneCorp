import Foundation

protocol Uploader {
    /// Starts all pending uploads
    func resume()
}

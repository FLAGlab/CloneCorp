#import <Foundation/Foundation.h>
#import "LocalCoreDataService.h"

@class ReaderPost;
@class ReaderAbstractTopic;

extern NSString * const ReaderPostServiceErrorDomain;
extern NSString * const ReaderPostServiceToggleSiteFollowingState;

@interface ReaderPostService : LocalCoreDataService

@property (copy, nonatomic) NSString *nextPageHandle;
@property (nonatomic) NSInteger pageNumber;

/**
 Fetches the posts for the specified topic

 @param topic The Topic for which to request posts.
 @param success block called on a successful fetch.
 @param failure block called if there is any error. `error` can be any underlying network error.
 */
- (void)fetchPostsForTopic:(ReaderAbstractTopic *)topic
                   success:(void (^)(NSInteger count, BOOL hasMore))success
                   failure:(void (^)(NSError *error))failure;

/**
 Fetches and saves the posts for the specified topic

 @param topic The Topic for which to request posts.
 @param date The date to get posts earlier than.
 @param success block called on a successful fetch.
 @param failure block called if there is any error. `error` can be any underlying network error.
 */
- (void)fetchPostsForTopic:(ReaderAbstractTopic *)topic
               earlierThan:(NSDate *)date
                   success:(void (^)(NSInteger count, BOOL hasMore))success
                   failure:(void (^)(NSError *error))failure;

/**
 Fetches and saves the posts for the specified topic

 @param topic The Topic for which to request posts.
 @param date The date to get posts earlier than.
 @param deletingEarlier Deletes any cached posts earlier than the earliers post returned.
 @param success block called on a successful fetch.
 @param failure block called if there is any error. `error` can be any underlying network error.
 */
- (void)fetchPostsForTopic:(ReaderAbstractTopic *)topic
               earlierThan:(NSDate *)date
           deletingEarlier:(BOOL)deleteEarlier
                   success:(void (^)(NSInteger count, BOOL hasMore))success
                   failure:(void (^)(NSError *error))failure;

/**
 Fetches and saves the posts for the specified topic

 @param topic The Topic for which to request posts.
 @param offset The offset of the posts to fetch.
 @param deletingEarlier Deletes any cached posts earlier than the earliers post returned.
 @param success block called on a successful fetch.
 @param failure block called if there is any error. `error` can be any underlying network error.
 */
- (void)fetchPostsForTopic:(ReaderAbstractTopic *)topic
                  atOffset:(NSUInteger)offset
           deletingEarlier:(BOOL)deleteEarlier
                   success:(void (^)(NSInteger count, BOOL hasMore))success
                   failure:(void (^)(NSError *error))failure;

/**
 Fetches a specific post from the specified remote site

 @param postID The ID of the post to fetch.
 @param siteID The ID of the post's site.
 @param success block called on a successful fetch.
 @param failure block called if there is any error. `error` can be any underlying network error.
 */
- (void)fetchPost:(NSUInteger)postID
          forSite:(NSUInteger)siteID
           isFeed:(BOOL)isFeed 
          success:(void (^)(ReaderPost *post))success
          failure:(void (^)(NSError *error))failure;

/**
 Fetches a specific post from the specified URL

 @param postURL The URL of the post to fetch
 @param success block called on a successful fetch.
 @param failure block called if there is any error. `error` can be any underlying network error.
 */
- (void)fetchPostAtURL:(NSURL *)postURL
          success:(void (^)(ReaderPost *post))success
          failure:(void (^)(NSError *error))failure;

/**
 Silently refresh posts for the followed sites topic.
 Note that calling this method creates a new service instance that performs
 all its work on a derived managed object context, and background queue.
 */
- (void)refreshPostsForFollowedTopic;

/**
 Toggle the liked status of the specified post.

 @param post The reader post to like/unlike.
 @param success block called on a successful fetch.
 @param failure block called if there is any error. `error` can be any underlying network error.
 */
- (void)toggleLikedForPost:(ReaderPost *)post
                   success:(void (^)(void))success
                   failure:(void (^)(NSError *error))failure;

/**
 Toggle the following status of the specified post's blog.

 @param post The ReaderPost whose blog should be followed.
 @param success block called on a successful fetch.
 @param failure block called if there is any error. `error` can be any underlying network error.
 */
- (void)toggleFollowingForPost:(ReaderPost *)post
                       success:(void (^)(void))success
                       failure:(void (^)(NSError *error))failure;

/**
 Toggle the saved for later status of the specified post.

 @param post The reader post to like/unlike.
 @param success block called on a successful fetch.
 @param failure block called if there is any error. `error` can be any underlying network error.
 */
- (void)toggleSavedForLaterForPost:(ReaderPost *)post
                           success:(void (^)(void))success
                           failure:(void (^)(NSError *error))failure;

/**
 Toggle the seen status of the specified post.
 
 @param post The reader post to mark seen/unseen.
 @param success block called on a successful fetch.
 @param failure block called if there is any error. `error` can be any underlying network error.
 */
- (void)toggleSeenForPost:(ReaderPost *)post
                  success:(void (^)(void))success
                  failure:(void (^)(NSError *error))failure;

/**
 Deletes all posts that do not belong to a `ReaderAbstractTopic`
 Saves the NSManagedObjectContext.
 */
- (void)deletePostsWithNoTopic;

/**
 Sets the `isSavedForLater` flag to false for all posts.
 */
- (void)clearSavedPostFlags;

/**
 Globally sets the `inUse` flag to false for all posts.
 */
- (void)clearInUseFlags;

/**
 Delete posts from the specified site/feed from the specified topic
 
 @param siteID The id of the site or feed.
 @param siteURL The URL of the site or feed.
 @param topic The `ReaderAbstractTopic` owning the posts.
 */
- (void)deletePostsWithSiteID:(NSNumber *)siteID
                   andSiteURL:(NSString *)siteURL
                    fromTopic:(ReaderAbstractTopic *)topic;

/**
 Delete posts from the specified site (not feed)

 @param siteID The id of the site or feed.
 */

- (void)deletePostsFromSiteWithID:(NSNumber *)siteID;

- (void)flagPostsFromSite:(NSNumber *)siteID asBlocked:(BOOL)blocked;

/**
 Follows or unfollows the specified site. Posts belonging to that site and URL
 have their following status updated in core data. 

 @param following Whether the user is following the site.
 @param siteID The ID of the site
 @siteURL the URL of the site. 
 @param success block called on a successful call.
 @param failure block called if there is any error. `error` can be any underlying network error.
 */
- (void)setFollowing:(BOOL)following
  forWPComSiteWithID:(NSNumber *)siteID
              andURL:(NSString *)siteURL
             success:(void (^)(void))success
             failure:(void (^)(NSError *error))failure;

/**
 Updates in core data the following status of posts belonging to the specified site & url

 @param following Whether the user is following the site.
 @param siteID The ID of the site
 @siteURL the URL of the site.
 */
- (void)setFollowing:(BOOL)following forPostsFromSiteWithID:(NSNumber *)siteID andURL:(NSString *)siteURL;

/**
 Delete all `ReaderPosts` beyond the max number to be retained.

 The managed object context is not saved.

 @param topic the `ReaderAbstractTopic` to delete posts from.
 */
- (void)deletePostsInExcessOfMaxAllowedForTopic:(ReaderAbstractTopic *)topic;

/**
 Delete posts that are flagged as belonging to a blocked site.

 The managed object context is not saved.
 */
- (void)deletePostsFromBlockedSites;

#pragma mark - Merging and Deletion

/**
 Merge a freshly fetched batch of posts into the existing set of posts for the specified topic.
 Saves the managed object context.

 @param remotePosts An array of RemoteReaderPost objects
 @param date The `before` date posts were requested.
 @param topicObjectID The ObjectID of the ReaderAbstractTopic to assign to the newly created posts.
 @param success block called on a successful fetch which should be performed after merging
 */
- (void)mergePosts:(NSArray *)remotePosts
    rankedLessThan:(NSNumber *)rank
          forTopic:(NSManagedObjectID *)topicObjectID
   deletingEarlier:(BOOL)deleteEarlier
    callingSuccess:(void (^)(NSInteger count, BOOL hasMore))success;

@end

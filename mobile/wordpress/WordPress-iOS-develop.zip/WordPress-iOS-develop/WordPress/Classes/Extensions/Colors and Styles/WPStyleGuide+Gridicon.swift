import WordPressShared

extension WPStyleGuide {
    @objc public class func cellGridiconAccessoryColor() -> UIColor {
        return UIColor(red: 200.0 / 255.0, green: 200.0 / 255.0, blue: 205.0 / 255.0, alpha: 1.0)
    }
}

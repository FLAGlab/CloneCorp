enum StoreFetchingStatus: Equatable {
    case idle
    case loading
    case success
    case error
}

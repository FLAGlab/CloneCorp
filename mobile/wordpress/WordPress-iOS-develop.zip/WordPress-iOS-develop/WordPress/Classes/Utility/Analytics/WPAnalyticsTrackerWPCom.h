#import <Foundation/Foundation.h>
#import <WordPressShared/WPAnalytics.h>

@interface WPAnalyticsTrackerWPCom : NSObject<WPAnalyticsTracker>

@end

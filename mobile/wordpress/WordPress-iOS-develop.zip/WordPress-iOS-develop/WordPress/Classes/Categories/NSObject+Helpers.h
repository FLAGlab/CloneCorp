#import <Foundation/Foundation.h>



@interface NSObject (Helpers)

+ (nonnull NSString *)classNameWithoutNamespaces;

@end

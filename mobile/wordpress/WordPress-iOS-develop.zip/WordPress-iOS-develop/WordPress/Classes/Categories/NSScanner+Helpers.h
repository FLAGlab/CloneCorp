#import <Foundation/Foundation.h>



@interface NSScanner (Helpers)

- (NSArray *)scanQuotedText;

@end

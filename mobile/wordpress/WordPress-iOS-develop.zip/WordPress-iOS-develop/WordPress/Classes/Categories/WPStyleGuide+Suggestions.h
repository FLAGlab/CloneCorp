#import <WordPressShared/WPStyleGuide.h>

@interface WPStyleGuide (Suggestions)

+ (UIColor *)suggestionsHeaderSmoke;
+ (UIColor *)suggestionsSeparatorSmoke;

@end

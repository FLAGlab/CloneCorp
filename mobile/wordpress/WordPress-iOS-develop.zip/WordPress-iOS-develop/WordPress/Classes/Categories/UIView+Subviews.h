#import <UIKit/UIKit.h>

@interface UIView (Subviews)

- (void)addSubviewWithFadeAnimation:(UIView *)subview;
- (void)fadeInWithAnimation;

@end

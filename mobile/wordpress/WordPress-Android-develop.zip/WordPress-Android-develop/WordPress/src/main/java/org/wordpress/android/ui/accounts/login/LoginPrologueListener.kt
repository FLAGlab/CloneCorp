package org.wordpress.android.ui.accounts.login

interface LoginPrologueListener {
    // Login Prologue callbacks
    fun showEmailLoginScreen()
    fun loginViaSiteAddress()
}

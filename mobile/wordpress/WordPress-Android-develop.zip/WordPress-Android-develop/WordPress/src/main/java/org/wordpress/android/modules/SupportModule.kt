package org.wordpress.android.modules

import com.automattic.android.tracks.crashlogging.CrashLogging
import dagger.Module
import dagger.Provides
import org.wordpress.android.fluxc.store.AccountStore
import org.wordpress.android.fluxc.store.SiteStore
import org.wordpress.android.support.SupportHelper
import org.wordpress.android.support.ZendeskHelper
import org.wordpress.android.support.ZendeskPlanFieldHelper
import org.wordpress.android.util.BuildConfigWrapper
import javax.inject.Singleton

@Module
class SupportModule {
    @Singleton
    @Provides
    fun provideZendeskHelper(
        accountStore: AccountStore,
        siteStore: SiteStore,
        supportHelper: SupportHelper,
        zendeskPlanFieldHelper: ZendeskPlanFieldHelper,
        buildConfigWrapper: BuildConfigWrapper
    ): ZendeskHelper = ZendeskHelper(accountStore, siteStore, supportHelper, zendeskPlanFieldHelper, buildConfigWrapper)

    @Singleton
    @Provides
    fun provideSupportHelper(): SupportHelper = SupportHelper()

    @Singleton
    @Provides
    fun provideZendeskPlanFieldHelper(remoteLoggingUtils: CrashLogging): ZendeskPlanFieldHelper =
        ZendeskPlanFieldHelper(remoteLoggingUtils)
}

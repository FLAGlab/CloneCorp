package org.wordpress.android.ui

interface ScrollableViewInitializedListener {
    fun onScrollableViewInitialized(containerId: Int)
}

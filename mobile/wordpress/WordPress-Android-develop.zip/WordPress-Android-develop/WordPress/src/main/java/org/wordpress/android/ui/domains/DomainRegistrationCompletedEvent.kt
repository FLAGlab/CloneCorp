package org.wordpress.android.ui.domains

data class DomainRegistrationCompletedEvent(val domainName: String, val email: String)

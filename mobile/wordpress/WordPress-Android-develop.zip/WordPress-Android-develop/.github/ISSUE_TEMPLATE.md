### Expected behavior


### Actual behavior


### Steps to reproduce the behavior


##### Tested on [device], Android [version], WPAndroid [version]
